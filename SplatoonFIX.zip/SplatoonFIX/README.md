
# Splatoon NoMotion (Cemu 1.26 or later)

![App Screenshot](https://cdn.discordapp.com/attachments/1005861052510117948/1005861123108647073/1con.png)

# Who?
this is a save and mod for Splatoon. In Cemu version 1.14 and the following versions, 
it worked incorrectly, and I redid it!  You can play Splatoon on a PC without a gyroscope (without a motion gamepad).

# Now to use?
 - [Now to download files](https://www.youtube.com/watch?v=bk0EtuDO3DQ&t)
 - Use DirectInput or keybord
 - Use Splatoon version 272





## Now to set DirectInput?
 [Click](https://youtu.be/bk0EtuDO3DQ?t=211)






## Gameplay with files

[click](https://youtu.be/bk0EtuDO3DQ?t=231)

## Authors

- [@MostDeviantAsiedu(original)](https://www.youtube.com/c/MostDeviantAsiedu)
- [@SipodNewmon(1.26 fix)](https://www.youtube.com/c/MostDeviantAsiedu)


